package com.acristyz.atmnearmeremastered;

import android.os.Bundle;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.acristyz.atmnearmeremastered.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        String customHTML = "<html><body style\"margin-top:0px; text-align:center\">"
                + "<iframe src=\"https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d446833.27406205947!2d4.870625811492575!3d50.784894286543!3m2!1i1024!2i768!4f13.1!2m1!1satm%20near%20me!5e0!3m2!1sro!2sbe!4v1624365988901!5m2!1sro!2sbe\" width=\"400\" height=\"900\" style=\"border:0;\" allowfullscreen=\"yes\" loading=\"lazy\"></iframe></html>";
        webView.loadData(customHTML, "text/html", "UTF-8");
        setContentView(webView);





    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (webView != null) {
            webView.destroy();
        }
    }


}